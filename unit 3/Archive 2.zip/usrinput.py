name=input('what is your name?')
print(f'name: {name}')
print(f'how you old you are: {int(input("how old are you?"))}')
